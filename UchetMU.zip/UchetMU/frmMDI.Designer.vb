﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMDI
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMDI))
        Me.hpAdvancedCHM = New System.Windows.Forms.HelpProvider()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.mnuList = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPodr = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMedUslugi = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEdIzm = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuVidRascheta = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuVidMedStrah = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuStrahComp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuStrahPolic = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuStatCalc = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCustomers = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPeriods = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.PrintToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintPreviewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintSetupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.UndoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolBarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusBarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAdmin = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileDB = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLinkWithAnother = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuYear = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu2008 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu2009 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDebug = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuImport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCreateDW = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuUslugi = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNal = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBeznal = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBeznalProekt = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBeznalFact = New System.Windows.Forms.ToolStripMenuItem()
        Me.ВоеннослужащиеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSoldAmb = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSoldSt = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDMS = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuStom = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReports = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAkt = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSFReport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPreiskurant = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPreiskurantBas = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPreiskurantOther = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuRepReestr = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuIncomesByPodr = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuZakaz = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuIncomesByStat = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuReestrUslugByStat = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFilter = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowsMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.CascadeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TileVerticalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TileHorizontalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ArrangeIconsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IndexToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РеестрToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РеестрToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.АктToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.butSave = New System.Windows.Forms.ToolStripButton()
        Me.MenuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'hpAdvancedCHM
        '
        Me.hpAdvancedCHM.HelpNamespace = "Resources\UchetMU.chm"
        '
        'MenuStrip
        '
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuList, Me.FileMenu, Me.EditMenu, Me.ViewMenu, Me.mnuAdmin, Me.ToolsMenu, Me.mnuUslugi, Me.mnuReports, Me.mnuFilter, Me.WindowsMenu, Me.HelpMenu})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.MdiWindowListItem = Me.WindowsMenu
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(632, 24)
        Me.MenuStrip.TabIndex = 5
        Me.MenuStrip.Text = "MenuStrip"
        '
        'mnuList
        '
        Me.mnuList.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuPodr, Me.mnuMedUslugi, Me.mnuEdIzm, Me.mnuVidRascheta, Me.mnuVidMedStrah, Me.mnuStrahComp, Me.mnuStrahPolic, Me.mnuStatCalc, Me.mnuCustomers, Me.mnuPeriods})
        Me.mnuList.Name = "mnuList"
        Me.mnuList.Size = New System.Drawing.Size(94, 20)
        Me.mnuList.Text = "&Справочники"
        '
        'mnuPodr
        '
        Me.mnuPodr.Name = "mnuPodr"
        Me.mnuPodr.Size = New System.Drawing.Size(250, 22)
        Me.mnuPodr.Text = "Подразделения"
        '
        'mnuMedUslugi
        '
        Me.mnuMedUslugi.Name = "mnuMedUslugi"
        Me.mnuMedUslugi.Size = New System.Drawing.Size(250, 22)
        Me.mnuMedUslugi.Text = "Медицинские услуги"
        '
        'mnuEdIzm
        '
        Me.mnuEdIzm.Name = "mnuEdIzm"
        Me.mnuEdIzm.Size = New System.Drawing.Size(250, 22)
        Me.mnuEdIzm.Text = "Единицы измерения услуг"
        '
        'mnuVidRascheta
        '
        Me.mnuVidRascheta.Name = "mnuVidRascheta"
        Me.mnuVidRascheta.Size = New System.Drawing.Size(250, 22)
        Me.mnuVidRascheta.Text = "Виды расчета за услугу"
        Me.mnuVidRascheta.Visible = False
        '
        'mnuVidMedStrah
        '
        Me.mnuVidMedStrah.Name = "mnuVidMedStrah"
        Me.mnuVidMedStrah.ShowShortcutKeys = False
        Me.mnuVidMedStrah.Size = New System.Drawing.Size(250, 22)
        Me.mnuVidMedStrah.Text = "Виды медицинского страхования"
        '
        'mnuStrahComp
        '
        Me.mnuStrahComp.Name = "mnuStrahComp"
        Me.mnuStrahComp.Size = New System.Drawing.Size(250, 22)
        Me.mnuStrahComp.Text = "Страховые компании"
        '
        'mnuStrahPolic
        '
        Me.mnuStrahPolic.Name = "mnuStrahPolic"
        Me.mnuStrahPolic.Size = New System.Drawing.Size(250, 22)
        Me.mnuStrahPolic.Text = "Медицинские полисы"
        '
        'mnuStatCalc
        '
        Me.mnuStatCalc.Name = "mnuStatCalc"
        Me.mnuStatCalc.Size = New System.Drawing.Size(250, 22)
        Me.mnuStatCalc.Text = "Статьи калькуляции"
        '
        'mnuCustomers
        '
        Me.mnuCustomers.Name = "mnuCustomers"
        Me.mnuCustomers.Size = New System.Drawing.Size(250, 22)
        Me.mnuCustomers.Text = "&Заказчики"
        '
        'mnuPeriods
        '
        Me.mnuPeriods.Name = "mnuPeriods"
        Me.mnuPeriods.Size = New System.Drawing.Size(250, 22)
        Me.mnuPeriods.Text = "Периоды"
        '
        'FileMenu
        '
        Me.FileMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.OpenToolStripMenuItem, Me.ToolStripSeparator3, Me.SaveToolStripMenuItem, Me.SaveAsToolStripMenuItem, Me.ToolStripSeparator4, Me.PrintToolStripMenuItem, Me.PrintPreviewToolStripMenuItem, Me.PrintSetupToolStripMenuItem, Me.ToolStripSeparator5, Me.ExitToolStripMenuItem})
        Me.FileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder
        Me.FileMenu.Name = "FileMenu"
        Me.FileMenu.Size = New System.Drawing.Size(37, 20)
        Me.FileMenu.Text = "&File"
        Me.FileMenu.Visible = False
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Image = CType(resources.GetObject("NewToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.NewToolStripMenuItem.Text = "&New"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Image = CType(resources.GetObject("OpenToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.OpenToolStripMenuItem.Text = "&Open"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(143, 6)
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Image = CType(resources.GetObject("SaveToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SaveToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.SaveToolStripMenuItem.Text = "&Save"
        '
        'SaveAsToolStripMenuItem
        '
        Me.SaveAsToolStripMenuItem.Name = "SaveAsToolStripMenuItem"
        Me.SaveAsToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.SaveAsToolStripMenuItem.Text = "Save &As"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(143, 6)
        '
        'PrintToolStripMenuItem
        '
        Me.PrintToolStripMenuItem.Image = CType(resources.GetObject("PrintToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.PrintToolStripMenuItem.Name = "PrintToolStripMenuItem"
        Me.PrintToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.PrintToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.PrintToolStripMenuItem.Text = "&Print"
        '
        'PrintPreviewToolStripMenuItem
        '
        Me.PrintPreviewToolStripMenuItem.Image = CType(resources.GetObject("PrintPreviewToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.PrintPreviewToolStripMenuItem.Name = "PrintPreviewToolStripMenuItem"
        Me.PrintPreviewToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.PrintPreviewToolStripMenuItem.Text = "Print Pre&view"
        '
        'PrintSetupToolStripMenuItem
        '
        Me.PrintSetupToolStripMenuItem.Name = "PrintSetupToolStripMenuItem"
        Me.PrintSetupToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.PrintSetupToolStripMenuItem.Text = "Print Setup"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(143, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'EditMenu
        '
        Me.EditMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UndoToolStripMenuItem, Me.RedoToolStripMenuItem, Me.ToolStripSeparator6, Me.CutToolStripMenuItem, Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem, Me.ToolStripSeparator7, Me.SelectAllToolStripMenuItem})
        Me.EditMenu.Name = "EditMenu"
        Me.EditMenu.Size = New System.Drawing.Size(39, 20)
        Me.EditMenu.Text = "&Edit"
        Me.EditMenu.Visible = False
        '
        'UndoToolStripMenuItem
        '
        Me.UndoToolStripMenuItem.Image = CType(resources.GetObject("UndoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UndoToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.UndoToolStripMenuItem.Name = "UndoToolStripMenuItem"
        Me.UndoToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.UndoToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.UndoToolStripMenuItem.Text = "&Undo"
        '
        'RedoToolStripMenuItem
        '
        Me.RedoToolStripMenuItem.Image = CType(resources.GetObject("RedoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RedoToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.RedoToolStripMenuItem.Name = "RedoToolStripMenuItem"
        Me.RedoToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Y), System.Windows.Forms.Keys)
        Me.RedoToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.RedoToolStripMenuItem.Text = "&Redo"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(161, 6)
        '
        'CutToolStripMenuItem
        '
        Me.CutToolStripMenuItem.Image = CType(resources.GetObject("CutToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.CutToolStripMenuItem.Name = "CutToolStripMenuItem"
        Me.CutToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.CutToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.CutToolStripMenuItem.Text = "Cu&t"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Image = CType(resources.GetObject("CopyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.CopyToolStripMenuItem.Text = "&Copy"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Image = CType(resources.GetObject("PasteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PasteToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.PasteToolStripMenuItem.Text = "&Paste"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(161, 6)
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select &All"
        '
        'ViewMenu
        '
        Me.ViewMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolBarToolStripMenuItem, Me.StatusBarToolStripMenuItem})
        Me.ViewMenu.Name = "ViewMenu"
        Me.ViewMenu.Size = New System.Drawing.Size(44, 20)
        Me.ViewMenu.Text = "&View"
        Me.ViewMenu.Visible = False
        '
        'ToolBarToolStripMenuItem
        '
        Me.ToolBarToolStripMenuItem.Checked = True
        Me.ToolBarToolStripMenuItem.CheckOnClick = True
        Me.ToolBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolBarToolStripMenuItem.Name = "ToolBarToolStripMenuItem"
        Me.ToolBarToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.ToolBarToolStripMenuItem.Text = "&Toolbar"
        '
        'StatusBarToolStripMenuItem
        '
        Me.StatusBarToolStripMenuItem.Checked = True
        Me.StatusBarToolStripMenuItem.CheckOnClick = True
        Me.StatusBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.StatusBarToolStripMenuItem.Name = "StatusBarToolStripMenuItem"
        Me.StatusBarToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.StatusBarToolStripMenuItem.Text = "&Status Bar"
        '
        'mnuAdmin
        '
        Me.mnuAdmin.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileDB, Me.mnuLinkWithAnother, Me.mnuYear, Me.mnuDebug, Me.mnuImport, Me.mnuCreateDW})
        Me.mnuAdmin.Name = "mnuAdmin"
        Me.mnuAdmin.Size = New System.Drawing.Size(59, 20)
        Me.mnuAdmin.Text = "&Сервис"
        '
        'mnuFileDB
        '
        Me.mnuFileDB.Name = "mnuFileDB"
        Me.mnuFileDB.Size = New System.Drawing.Size(270, 22)
        Me.mnuFileDB.Text = "&Файл базы данных"
        '
        'mnuLinkWithAnother
        '
        Me.mnuLinkWithAnother.Name = "mnuLinkWithAnother"
        Me.mnuLinkWithAnother.Size = New System.Drawing.Size(270, 22)
        Me.mnuLinkWithAnother.Text = "Связать с другим..."
        Me.mnuLinkWithAnother.Visible = False
        '
        'mnuYear
        '
        Me.mnuYear.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu2008, Me.mnu2009})
        Me.mnuYear.Name = "mnuYear"
        Me.mnuYear.Size = New System.Drawing.Size(270, 22)
        Me.mnuYear.Text = "Текущий год"
        '
        'mnu2008
        '
        Me.mnu2008.Name = "mnu2008"
        Me.mnu2008.Size = New System.Drawing.Size(98, 22)
        Me.mnu2008.Text = "2008"
        '
        'mnu2009
        '
        Me.mnu2009.Name = "mnu2009"
        Me.mnu2009.Size = New System.Drawing.Size(98, 22)
        Me.mnu2009.Text = "2009"
        '
        'mnuDebug
        '
        Me.mnuDebug.Name = "mnuDebug"
        Me.mnuDebug.Size = New System.Drawing.Size(270, 22)
        Me.mnuDebug.Text = "Режим отладки"
        '
        'mnuImport
        '
        Me.mnuImport.Name = "mnuImport"
        Me.mnuImport.Size = New System.Drawing.Size(270, 22)
        Me.mnuImport.Text = "Импорт счетов-фактур"
        '
        'mnuCreateDW
        '
        Me.mnuCreateDW.Name = "mnuCreateDW"
        Me.mnuCreateDW.Size = New System.Drawing.Size(270, 22)
        Me.mnuCreateDW.Text = "Сформировать хранилище отчетов"
        '
        'ToolsMenu
        '
        Me.ToolsMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OptionsToolStripMenuItem})
        Me.ToolsMenu.Name = "ToolsMenu"
        Me.ToolsMenu.Size = New System.Drawing.Size(48, 20)
        Me.ToolsMenu.Text = "&Tools"
        Me.ToolsMenu.Visible = False
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.OptionsToolStripMenuItem.Text = "&Options"
        '
        'mnuUslugi
        '
        Me.mnuUslugi.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuNal, Me.mnuBeznal, Me.ВоеннослужащиеToolStripMenuItem, Me.mnuDMS, Me.mnuStom})
        Me.mnuUslugi.Name = "mnuUslugi"
        Me.mnuUslugi.Size = New System.Drawing.Size(57, 20)
        Me.mnuUslugi.Text = "Услуги"
        '
        'mnuNal
        '
        Me.mnuNal.Name = "mnuNal"
        Me.mnuNal.Size = New System.Drawing.Size(189, 22)
        Me.mnuNal.Text = "Наличный расчет"
        '
        'mnuBeznal
        '
        Me.mnuBeznal.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuBeznalProekt, Me.mnuBeznalFact})
        Me.mnuBeznal.Name = "mnuBeznal"
        Me.mnuBeznal.Size = New System.Drawing.Size(189, 22)
        Me.mnuBeznal.Text = "Безналичный расчет"
        '
        'mnuBeznalProekt
        '
        Me.mnuBeznalProekt.Name = "mnuBeznalProekt"
        Me.mnuBeznalProekt.Size = New System.Drawing.Size(174, 22)
        Me.mnuBeznalProekt.Text = "Предварительные"
        '
        'mnuBeznalFact
        '
        Me.mnuBeznalFact.Name = "mnuBeznalFact"
        Me.mnuBeznalFact.Size = New System.Drawing.Size(174, 22)
        Me.mnuBeznalFact.Text = "Фактические"
        '
        'ВоеннослужащиеToolStripMenuItem
        '
        Me.ВоеннослужащиеToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuSoldAmb, Me.mnuSoldSt})
        Me.ВоеннослужащиеToolStripMenuItem.Name = "ВоеннослужащиеToolStripMenuItem"
        Me.ВоеннослужащиеToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.ВоеннослужащиеToolStripMenuItem.Text = "Военнослужащие"
        '
        'mnuSoldAmb
        '
        Me.mnuSoldAmb.Name = "mnuSoldAmb"
        Me.mnuSoldAmb.Size = New System.Drawing.Size(307, 22)
        Me.mnuSoldAmb.Text = "Амбулаторная поликлиническая помощь"
        '
        'mnuSoldSt
        '
        Me.mnuSoldSt.Name = "mnuSoldSt"
        Me.mnuSoldSt.Size = New System.Drawing.Size(307, 22)
        Me.mnuSoldSt.Text = "Мед. услуги по стационарам"
        '
        'mnuDMS
        '
        Me.mnuDMS.Name = "mnuDMS"
        Me.mnuDMS.Size = New System.Drawing.Size(189, 22)
        Me.mnuDMS.Text = "ДМС"
        '
        'mnuStom
        '
        Me.mnuStom.Name = "mnuStom"
        Me.mnuStom.Size = New System.Drawing.Size(189, 22)
        Me.mnuStom.Text = "Стоматология"
        '
        'mnuReports
        '
        Me.mnuReports.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAkt, Me.mnuSFReport, Me.mnuPreiskurant, Me.mnuRepReestr, Me.mnuIncomesByPodr, Me.mnuZakaz, Me.mnuIncomesByStat, Me.mnuReestrUslugByStat})
        Me.mnuReports.Name = "mnuReports"
        Me.mnuReports.Size = New System.Drawing.Size(60, 20)
        Me.mnuReports.Text = "Отчеты"
        '
        'mnuAkt
        '
        Me.mnuAkt.Name = "mnuAkt"
        Me.mnuAkt.Size = New System.Drawing.Size(289, 22)
        Me.mnuAkt.Text = "Акт по СФ"
        Me.mnuAkt.Visible = False
        '
        'mnuSFReport
        '
        Me.mnuSFReport.Name = "mnuSFReport"
        Me.mnuSFReport.Size = New System.Drawing.Size(289, 22)
        Me.mnuSFReport.Text = "Реестр по СФ"
        Me.mnuSFReport.Visible = False
        '
        'mnuPreiskurant
        '
        Me.mnuPreiskurant.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuPreiskurantBas, Me.mnuPreiskurantOther})
        Me.mnuPreiskurant.Name = "mnuPreiskurant"
        Me.mnuPreiskurant.Size = New System.Drawing.Size(289, 22)
        Me.mnuPreiskurant.Text = "Прейскурант цен"
        '
        'mnuPreiskurantBas
        '
        Me.mnuPreiskurantBas.Name = "mnuPreiskurantBas"
        Me.mnuPreiskurantBas.Size = New System.Drawing.Size(207, 22)
        Me.mnuPreiskurantBas.Text = "Основной"
        '
        'mnuPreiskurantOther
        '
        Me.mnuPreiskurantOther.Name = "mnuPreiskurantOther"
        Me.mnuPreiskurantOther.Size = New System.Drawing.Size(207, 22)
        Me.mnuPreiskurantOther.Text = "Прочие платные услуги"
        '
        'mnuRepReestr
        '
        Me.mnuRepReestr.Name = "mnuRepReestr"
        Me.mnuRepReestr.Size = New System.Drawing.Size(289, 22)
        Me.mnuRepReestr.Text = "Оказанные услуги за наличный расчет"
        '
        'mnuIncomesByPodr
        '
        Me.mnuIncomesByPodr.Name = "mnuIncomesByPodr"
        Me.mnuIncomesByPodr.Size = New System.Drawing.Size(289, 22)
        Me.mnuIncomesByPodr.Text = "Доходы по подразделениям и статьям"
        '
        'mnuZakaz
        '
        Me.mnuZakaz.Name = "mnuZakaz"
        Me.mnuZakaz.Size = New System.Drawing.Size(289, 22)
        Me.mnuZakaz.Text = "Наряд-заказ"
        Me.mnuZakaz.Visible = False
        '
        'mnuIncomesByStat
        '
        Me.mnuIncomesByStat.Name = "mnuIncomesByStat"
        Me.mnuIncomesByStat.Size = New System.Drawing.Size(289, 22)
        Me.mnuIncomesByStat.Text = "Доходы по статьям"
        '
        'mnuReestrUslugByStat
        '
        Me.mnuReestrUslugByStat.Name = "mnuReestrUslugByStat"
        Me.mnuReestrUslugByStat.Size = New System.Drawing.Size(289, 22)
        Me.mnuReestrUslugByStat.Text = "Оказанные услуги по статьям"
        '
        'mnuFilter
        '
        Me.mnuFilter.Name = "mnuFilter"
        Me.mnuFilter.Size = New System.Drawing.Size(60, 20)
        Me.mnuFilter.Text = "&Фильтр"
        Me.mnuFilter.Visible = False
        '
        'WindowsMenu
        '
        Me.WindowsMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CascadeToolStripMenuItem, Me.TileVerticalToolStripMenuItem, Me.TileHorizontalToolStripMenuItem, Me.CloseAllToolStripMenuItem, Me.ArrangeIconsToolStripMenuItem})
        Me.WindowsMenu.Name = "WindowsMenu"
        Me.WindowsMenu.Size = New System.Drawing.Size(47, 20)
        Me.WindowsMenu.Text = "&Окна"
        '
        'CascadeToolStripMenuItem
        '
        Me.CascadeToolStripMenuItem.Name = "CascadeToolStripMenuItem"
        Me.CascadeToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.CascadeToolStripMenuItem.Text = "&Каскакдом"
        '
        'TileVerticalToolStripMenuItem
        '
        Me.TileVerticalToolStripMenuItem.Name = "TileVerticalToolStripMenuItem"
        Me.TileVerticalToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.TileVerticalToolStripMenuItem.Text = "&Вертикально"
        '
        'TileHorizontalToolStripMenuItem
        '
        Me.TileHorizontalToolStripMenuItem.Name = "TileHorizontalToolStripMenuItem"
        Me.TileHorizontalToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.TileHorizontalToolStripMenuItem.Text = "&Горизонтально"
        '
        'CloseAllToolStripMenuItem
        '
        Me.CloseAllToolStripMenuItem.Name = "CloseAllToolStripMenuItem"
        Me.CloseAllToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.CloseAllToolStripMenuItem.Text = "&Закрыть все"
        '
        'ArrangeIconsToolStripMenuItem
        '
        Me.ArrangeIconsToolStripMenuItem.Name = "ArrangeIconsToolStripMenuItem"
        Me.ArrangeIconsToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.ArrangeIconsToolStripMenuItem.Text = "&Расположить иконки"
        '
        'HelpMenu
        '
        Me.HelpMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContentsToolStripMenuItem, Me.IndexToolStripMenuItem, Me.SearchToolStripMenuItem, Me.ToolStripSeparator8, Me.AboutToolStripMenuItem})
        Me.HelpMenu.Name = "HelpMenu"
        Me.HelpMenu.Size = New System.Drawing.Size(24, 20)
        Me.HelpMenu.Text = "&?"
        '
        'ContentsToolStripMenuItem
        '
        Me.ContentsToolStripMenuItem.Name = "ContentsToolStripMenuItem"
        Me.ContentsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F1), System.Windows.Forms.Keys)
        Me.ContentsToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.ContentsToolStripMenuItem.Text = "&Содержание"
        '
        'IndexToolStripMenuItem
        '
        Me.IndexToolStripMenuItem.Image = CType(resources.GetObject("IndexToolStripMenuItem.Image"), System.Drawing.Image)
        Me.IndexToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.IndexToolStripMenuItem.Name = "IndexToolStripMenuItem"
        Me.IndexToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.IndexToolStripMenuItem.Text = "&Индекс"
        Me.IndexToolStripMenuItem.Visible = False
        '
        'SearchToolStripMenuItem
        '
        Me.SearchToolStripMenuItem.Image = CType(resources.GetObject("SearchToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SearchToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black
        Me.SearchToolStripMenuItem.Name = "SearchToolStripMenuItem"
        Me.SearchToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.SearchToolStripMenuItem.Text = "&Поиск"
        Me.SearchToolStripMenuItem.Visible = False
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(186, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.AboutToolStripMenuItem.Text = "&О программе..."
        '
        'РеестрToolStripMenuItem
        '
        Me.РеестрToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.РеестрToolStripMenuItem1, Me.АктToolStripMenuItem})
        Me.РеестрToolStripMenuItem.Name = "РеестрToolStripMenuItem"
        Me.РеестрToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.РеестрToolStripMenuItem.Text = "Для страховой компании"
        Me.РеестрToolStripMenuItem.Visible = False
        '
        'РеестрToolStripMenuItem1
        '
        Me.РеестрToolStripMenuItem1.Name = "РеестрToolStripMenuItem1"
        Me.РеестрToolStripMenuItem1.Size = New System.Drawing.Size(111, 22)
        Me.РеестрToolStripMenuItem1.Text = "Реестр"
        '
        'АктToolStripMenuItem
        '
        Me.АктToolStripMenuItem.Name = "АктToolStripMenuItem"
        Me.АктToolStripMenuItem.Size = New System.Drawing.Size(111, 22)
        Me.АктToolStripMenuItem.Text = "Акт"
        '
        'StatusStrip
        '
        Me.StatusStrip.Location = New System.Drawing.Point(0, 431)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(632, 22)
        Me.StatusStrip.TabIndex = 7
        Me.StatusStrip.Text = "StatusStrip"
        '
        'ToolStripStatusLabel
        '
        Me.ToolStripStatusLabel.Name = "ToolStripStatusLabel"
        Me.ToolStripStatusLabel.Size = New System.Drawing.Size(38, 17)
        Me.ToolStripStatusLabel.Text = "Status"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(632, 25)
        Me.ToolStrip1.TabIndex = 9
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'butSave
        '
        Me.butSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.butSave.Image = CType(resources.GetObject("butSave.Image"), System.Drawing.Image)
        Me.butSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.butSave.Name = "butSave"
        Me.butSave.Size = New System.Drawing.Size(23, 22)
        Me.butSave.Text = "ToolStripButton1"
        Me.butSave.ToolTipText = "Сохранить"
        '
        'frmMDI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(632, 453)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip)
        Me.Controls.Add(Me.StatusStrip)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip
        Me.Name = "frmMDI"
        Me.Text = "Учет МедУслуг 1.0"
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ContentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IndexToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ArrangeIconsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WindowsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CascadeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TileVerticalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TileHorizontalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents ToolStripStatusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents PrintPreviewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PrintSetupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveAsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents EditMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UndoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RedoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SelectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolBarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusBarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuVidMedStrah As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEdIzm As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMedUslugi As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPodr As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAdmin As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuVidRascheta As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuStrahComp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuStrahPolic As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuStatCalc As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuUslugi As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFilter As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuReports As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPreiskurant As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuRepReestr As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuIncomesByPodr As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents РеестрToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents РеестрToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents АктToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuCustomers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileDB As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLinkWithAnother As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents butSave As System.Windows.Forms.ToolStripButton
    Friend WithEvents mnuPreiskurantBas As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPreiskurantOther As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ВоеннослужащиеToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSoldAmb As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSoldSt As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDMS As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPeriods As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuBeznal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSFReport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuYear As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu2008 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu2009 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuBeznalProekt As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuBeznalFact As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDebug As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuStom As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAkt As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuZakaz As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuReestrUslugByStat As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuIncomesByStat As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuImport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuCreateDW As System.Windows.Forms.ToolStripMenuItem

End Class
